﻿#include "LCD_Test.h"   //Examples

int main(void)
{
    LCD_1in47_test();
    return 0;
}
